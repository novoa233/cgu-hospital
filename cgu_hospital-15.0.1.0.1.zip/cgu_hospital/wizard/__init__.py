from . import cgu_hospital_set_doctor_wizard
